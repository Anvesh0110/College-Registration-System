#include <bits/stdc++.h>
#include "module.h"
using namespace std;
void add_module()
{
    module data;
    cout<<"Enter Module Information below -"<<endl;
    cout<<"Module No : ";
    cin>>data.moduleNo;
    cout<<endl<<"Module Name : ";
    getline(cin,data.moduleName);
    cout<<endl<<"Duration in months : ";
    cin>>data.duration;
    cout<<endl<<"Module fee in INR : ";
    cin>>data.fees;
    cout<<endl<<"Tentative start date : ";
    getline(cin,data.tentativeStartDate);
    moduleInfo.push_back(data);
}
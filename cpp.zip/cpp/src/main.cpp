#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int choice;
    cout<<"# College Registration System #"<<endl;
    cout<<"1> Add Record"<<endl;
    cout<<"2> Update Record"<<endl;
    cout<<"3> Get All Records"<<endl;
    cout<<"4> Add Module"<<endl;
    cout<<"5> Get All Module Details"<<endl;
    cout<<"6> Update Module"<<endl;
    cout<<"0> Exit..."<<endl;
    cout<<" Enter your choice : ";
    cin>>choice;
    switch(choice)
    {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 0:
        default:
    }
}
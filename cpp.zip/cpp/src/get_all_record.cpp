#include <bits/stdc++.h>
#include "student.h"
using namespace std;
void display_records()
{
    int sr_no=1;
    for(auto it:studentInfo)
    {
        cout<<"Information of Student "<<sr_no<<" : "<<endl;
        cout<<"Student ID : "<<it.student_id<<endl;
        cout<<"Student Name : "<<it.studName<<endl;
        cout<<"Student Gender : "<<it.gender<<endl;
        cout<<"Student Blood Group : "<<it.bloodGrp<<endl;
        cout<<"Student Address : "<<it.studAddr<<endl; 
        cout<<"Student Date of Birth : "<<it.dob<<endl;   
        sr_no++;            
    }
}
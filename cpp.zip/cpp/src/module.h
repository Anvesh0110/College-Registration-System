#include<bits/stdc++.h>
using namespace std;

class module
{
    public:
    int moduleNo,duration,fees;
    string moduleName,tentativeStartDate;
};
vector<module> moduleInfo;
void add_module();
void display_modules();
void update_module();
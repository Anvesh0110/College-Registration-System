#include <bits/stdc++.h>
#include "student.h"
using namespace std;
void update_record()
{
    int id,choice;
    cout<<"Enter Student ID to be updated - "<<endl;
    cin>>id;
    while(true)
    {
        cout<<"Enter 1 to update name"<<endl;
        cout<<"Enter 2 to update gender"<<endl;
        cout<<"Enter 3 to update blood group"<<endl;
        cout<<"Enter 4 to update address"<<endl;
        cout<<"Enter 5 to update date of birth"<<endl;
        cout<<"Enter 0 to stop updating further"<<endl;
        cout<<"Enter choice <0-5> : ";
        cin>>choice;        
        switch(choice)
        {
            case 0 : break;
            case 1 : cout<<"Enter updated name"<<endl;
                     cin>>studentInfo[id].studName;
                     break;
            case 2 : cout<<"Enter updated gender"<<endl;
                     cin>>studentInfo[id].gender;
                     break;
            case 3 : cout<<"Enter updated blood group"<<endl;
                     cin>>studentInfo[id].bloodGrp;
                     break;
            case 4 : cout<<"Enter updated address"<<endl;
                     cin>>studentInfo[id].studAddr;
                     break;
            case 5 : cout<<"Enter updated date of birth"<<endl;
                     cin>>studentInfo[id].dob;
                     break;
        }
    }
}
#include <bits/stdc++.h>
#include "student.h"
using namespace std;
void add_record()
{
    student record;
    cout<<"Enter Student Information below -"<<endl;
    cout<<"Student ID : ";
    cin>>record.student_id;
    cout<<endl<<"Student Name : ";
    getline(cin,record.studName);
    cout<<endl<<"Gender : ";
    cin>>record.gender;
    cout<<endl<<"Blood Group : ";
    getline(cin,record.bloodGrp);
    cout<<endl<<"Address : ";
    getline(cin,record.studAddr);
    cout<<endl<<"Date of Birth : ";
    getline(cin,record.dob);
    studentInfo.push_back(record);
}